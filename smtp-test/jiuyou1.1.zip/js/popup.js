Array.prototype.contain = function(v){
		if(this.length==0)return false;
		for(var i=this.length-1;i>=0;i--){
			if(this[i] == v)return true;
		}
		return false;
}
var flagMap = {'jp':'日本','us':'美国','en':'英国','kr':'韩国','hk':'香港','mc':'澳门','sg':'新加坡','tw':'台湾','ca':'加拿大'};
var statusMap = {'ZC':{zh:'正常',cls:'btn-success'},'YJ':{zh:'拥挤',cls:'btn-warning'},'TZ':{zh:'停止',cls:'disabled'}};
var proxyList = {};
var currentProxy;
var telanx;
var Ext = {
	loadProxyList:function(list,currentProxy) {
		
		var dom = $(".table tbody");
		dom.html("");
		
		for(var i=0;i<list.length;i++){
			var lt = list[i];
			var css = (lt.id===currentProxy.id?"selected":"");
			dom.append('<tr class="proxy '+css+'">'
						 +'<td class="proxyname" data-id='+lt.id+'>'+lt.name+'</td>'
						 +'<td>'
						 +'<div class="flag"><img src="/img/flags/'+lt.country+'.png"></div>'
						 +'<div class="ip" hidden>'+lt.ip+'</div>'
						 +'<div class="port" hidden>'+lt.port+'</div>'
						 +'<div class="type" hidden>'+lt.type+'</div>'
						 +'<div class="spcode" hidden>'+lt.spcode+'</div>'
						 +'<div class="up" hidden>'+lt.up+'</div>'
						 +'<div class="locate" code='+lt.country+'><!--'+flagMap[lt.country]+'--></div>'
						 +'</td>'
						 +'<td><button class="btn btn-xs '+statusMap[lt.status].cls+'">'+statusMap[lt.status].zh+'</button></td>'
					 +'</tr>');
		}
	},
	loadCurrentProxy:function(currentProxy){
		if(currentProxy.id!=undefined){
			$(".node").find("img").attr("src","/img/flags/"+currentProxy.country+".png");
			$(".node").find(".locate").text(flagMap[currentProxy.country]);
		}else{
			$(".node").html("当前无任何可用服务！");
		}
	},
	getLeastUsedProxy:function(proxyList,fields){
		var len = proxyList.length;
		var minNum = 100000;
		var index = 0;
		var leastUsedProxy;
		var rs = {};
		for(var i=0;i<len;i++){
			var num = proxyList[i].num;
			if(num<minNum){
				minNum = num;
				index = i;
			}
		}
		leastUsedProxy = proxyList[index];
		for(i=0;i<fields.length;i++){
			rs[fields[i]] = leastUsedProxy[fields[i]];
		}
		return rs;
	},
	switchToProxy:function(proxy,fn){
		chrome.runtime.sendMessage({
				from:'popup',
				type:'switchProxy',
				spcode: proxy.spcode,
				up: proxy.up
		},function(r){
			fn();
		});
	},
	report:function(type, pid){
		//type = enum {"add","del"}
	}
}
$(function(){
	var popup = (new Popup()).getInstance();
	currentProxy = JSON.parse(localStorage['currentProxy']||'{}');
	//获取当前网址信息
	chrome.extension.sendMessage({from:'popup',type:'query'},function(r){
			if(r.userInfo!=undefined && r.userInfo.isExpired){
				location.href = 'expired.html';
				return false;
			}
			if(r.userInfo!=undefined && r.userInfo.expireDate=='未激活'){
				location.href = '.html';
				return false;
			}
			$('.mask').hide();
			telanx = r;
			proxyList = r.userInfo.proxyList||[];
			for(var i=0;i<proxyList.length;i++){
				if(proxyList[i].id === currentProxy.id){
					currentProxy = {id:proxyList[i].id,ip:proxyList[i].ip,country:proxyList[i].country};
					break;
				}
			}
			if(proxyList.length && !currentProxy.id){
				//没有从本地找到对应的代理服务则自动使用人数最少的代理服务器
				currentProxy = Ext.getLeastUsedProxy(proxyList,['id','ip','country']);
				localStorage['currentProxy'] = JSON.stringify(currentProxy);
			}
			Ext.loadProxyList(proxyList,currentProxy);
			Ext.loadCurrentProxy(currentProxy);
			$('.mode-switch[data-id='+r.mode+']').addClass('btn-primary');
			
			//插件服务器不可用，提示公告信息
			if(!r.userInfo || JSON.stringify(r.userInfo)==='{}'){
				$('.mask').show();
				return false;
			}
			//未登录，请先登录插件
			if(r.userInfo.user==null){
				window.open('options.html');
				return false;
			}
			var host = (r.page||{url:'protrol://未知域名'}).url.split('/')[2];
			var tip,mhost;
			if(host.split('.').length>1){
				tip = '当前域名:'+host;
			}else{
				tip = '久游';
			}
			$('#cpHost').html(tip);
			
			
			//获取domainList列表
			var domainList = (localStorage['domainList']||'').split(',');
			if(host && host.split('.').length>1){
				if(domainList.contain(host))$('.contain').show();
				else $('.notcontain').show();
			}else{
				$('.invalidDomain').show();
			}
			
			//侦听事件
			$('.add').click(function(){
				$('.contain').show();
				$('.notcontain').hide();
				chrome.runtime.sendMessage({from:'popup',type:'domain',v:host});
			});
			$('.del').click(function(){
				$('.notcontain').show();
				$('.contain').hide();
				chrome.runtime.sendMessage({from:'popup',type:'domain',v:host});
			})
			
			$('.mode-switch').click(function(e){
				var d = e.target;
				chrome.runtime.sendMessage({from:'popup',type:'mode',v:$(d).attr('data-id')},function(r){
					if(r.rs){
						$('.mode-switch').removeClass('btn-primary');
						$(d).addClass('btn-primary');
					}else{
						popup.showTip(r.msg);
					}
				});
			});
			
			$(".node").click(function(){
				$("#slidepage").animate({marginLeft:'-250px'});
			});
			//更新节点信息
			$(".refresh").click(function(){
				var proxyMsg = '正在获取节点信息...';
				$('.proxyStatus .status').html(proxyMsg);
				popup.showTip(proxyMsg);
				console.log(telanx.rcfg);
				$.getJSON(telanx.crx.server.ROOT+telanx.crx.server.getProxyListUrl,function(r){
					popup.hideTip();
					if(typeof r == 'object'){
						$('.proxyStatus .status').html("获取成功！");
						Ext.loadProxyList(r||[],currentProxy);
						chrome.runtime.sendMessage({from:'option',type:'sync',userInfo:{ proxyList:r } });
						//Ext.sync('proxyList',r);
					}
				});
			});
			$(".backhome").click(function(){
				$("#slidepage").animate({marginLeft:'0px'});
			});
			
			//切换节点
			$(".nodelist").on("click",".proxy",function(e){
				var proxyName = $(this).find(".proxyname").text();
				var proxyId = $(this).children(":eq(0)").attr("data-id").replace("#","");
				var ip = $(this).find(".ip").text();
				var country = $(this).find(".locate").attr("code");
				var type = $(this).find(".type").text();
				var port = $(this).find(".port").text();
				var spcode = $(this).find(".spcode").text();
				var up = $(this).find(".up").text();
				$(".proxyStatus>.status").html("正在切换至"+proxyName+"...");
				popup.showTip("正在切换节点");
				var _this = this;
				Ext.switchToProxy({
					spcode: spcode ? spcode : (type+' '+ip+':'+port),
					up: up
				},function(){
					popup.hideTip();
					currentProxy = {id:proxyId,ip:ip,country:country};
					localStorage['currentProxy'] = JSON.stringify(currentProxy);
					Ext.loadCurrentProxy(currentProxy);
					//成功
					
					$(".proxyStatus>.status").html("已经切换至"+proxyName);
					//Ext.report(proxyId);
					
					$(".proxy").removeClass("selected");
					$(_this).addClass("selected");
				});
				
				
				//每次切换节点时自动上报到服务器，以获取各个代理服务器实时使用人数
			});
			
			
	});
});

